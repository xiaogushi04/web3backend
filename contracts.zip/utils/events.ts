import { ethers } from 'ethers';
import { getProvider } from '../services/web3';
import { CONTRACT_ADDRESSES } from '../services/web3';
import NFTAbi from '../contracts/NFT.json';
import ReferenceAbi from '../contracts/Reference.json';

// 事件监听器类型
type EventListener = (event: any) => void;

// 事件监听管理器
class EventManager {
  private provider: ethers.providers.Web3Provider;
  private nftContract: ethers.Contract;
  private referenceContract: ethers.Contract;
  private listeners: Map<string, EventListener[]>;

  constructor() {
    this.provider = getProvider();
    this.nftContract = new ethers.Contract(CONTRACT_ADDRESSES.NFT, NFTAbi, this.provider);
    this.referenceContract = new ethers.Contract(CONTRACT_ADDRESSES.REFERENCE, ReferenceAbi, this.provider);
    this.listeners = new Map();
  }

  // 监听NFT铸造事件
  public listenToNFTMint(callback: EventListener) {
    const filter = this.nftContract.filters.ResourceMinted();
    this.nftContract.on(filter, (tokenId, author, ipfsHash, event) => {
      callback({
        tokenId,
        author,
        ipfsHash,
        event
      });
    });
    this.addListener('NFTMint', callback);
  }

  // 监听引用创建事件
  public listenToReferenceCreated(callback: EventListener) {
    const filter = this.referenceContract.filters.ReferenceCreated();
    this.referenceContract.on(filter, (referenceId, sourceTokenId, targetTokenId, referencer, event) => {
      callback({
        referenceId,
        sourceTokenId,
        targetTokenId,
        referencer,
        event
      });
    });
    this.addListener('ReferenceCreated', callback);
  }

  // 添加监听器
  private addListener(eventName: string, callback: EventListener) {
    if (!this.listeners.has(eventName)) {
      this.listeners.set(eventName, []);
    }
    this.listeners.get(eventName)?.push(callback);
  }

  // 移除监听器
  public removeListener(eventName: string, callback: EventListener) {
    const listeners = this.listeners.get(eventName);
    if (listeners) {
      const index = listeners.indexOf(callback);
      if (index > -1) {
        listeners.splice(index, 1);
      }
    }
  }

  // 清除所有监听器
  public clearAllListeners() {
    this.nftContract.removeAllListeners();
    this.referenceContract.removeAllListeners();
    this.listeners.clear();
  }
}

export const eventManager = new EventManager();