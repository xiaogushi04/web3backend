import { create } from 'ipfs-http-client';
import { Buffer } from 'buffer';

// IPFS客户端配置
const ipfs = create({ url: process.env.REACT_APP_IPFS_API_URL || 'http://localhost:5001' });

// 上传数据到IPFS
export const uploadToIPFS = async (data: any): Promise<string> => {
  try {
    const result = await ipfs.add(Buffer.from(JSON.stringify(data)));
    return result.path;
  } catch (error) {
    console.error('Failed to upload to IPFS:', error);
    throw error;
  }
};

// 从IPFS获取数据
export const getFromIPFS = async (hash: string): Promise<any> => {
  try {
    const stream = ipfs.cat(hash);
    const chunks = [];
    for await (const chunk of stream) {
      chunks.push(chunk);
    }
    const data = Buffer.concat(chunks).toString();
    return JSON.parse(data);
  } catch (error) {
    console.error('Failed to get from IPFS:', error);
    throw error;
  }
};

// 维护NFT与IPFS数据一致性
export const syncNFTWithIPFS = async (tokenId: string, metadata: any): Promise<string> => {
  try {
    // 上传新的元数据到IPFS
    const ipfsHash = await uploadToIPFS(metadata);
    
    // TODO: 更新NFT合约中的tokenURI
    // 这部分需要与NFT合约交互
    
    return ipfsHash;
  } catch (error) {
    console.error('Failed to sync NFT with IPFS:', error);
    throw error;
  }
};

export class IPFSService {
    private static instance: IPFSService;
    private ipfs: any;

    private constructor() {
        // 连接到IPFS节点
        this.ipfs = create({
            host: process.env.REACT_APP_IPFS_HOST || 'ipfs.infura.io',
            port: 5001,
            protocol: 'https',
            headers: {
                authorization: `Basic ${Buffer.from(
                    `${process.env.REACT_APP_IPFS_PROJECT_ID}:${process.env.REACT_APP_IPFS_PROJECT_SECRET}`
                ).toString('base64')}`
            }
        });
    }

    public static getInstance(): IPFSService {
        if (!IPFSService.instance) {
            IPFSService.instance = new IPFSService();
        }
        return IPFSService.instance;
    }

    // 上传文件到IPFS
    public async uploadFile(file: File): Promise<string> {
        try {
            const added = await this.ipfs.add(file);
            return added.path;
        } catch (error) {
            console.error('IPFS upload failed:', error);
            throw new Error('文件上传失败');
        }
    }

    // 上传JSON数据到IPFS
    public async uploadJSON(data: any): Promise<string> {
        try {
            const buffer = Buffer.from(JSON.stringify(data));
            const added = await this.ipfs.add(buffer);
            return added.path;
        } catch (error) {
            console.error('IPFS JSON upload failed:', error);
            throw new Error('数据上传失败');
        }
    }

    // 从IPFS获取文件
    public async getFile(hash: string): Promise<Blob> {
        try {
            const stream = this.ipfs.cat(hash);
            const chunks = [];
            
            for await (const chunk of stream) {
                chunks.push(chunk);
            }
            
            return new Blob(chunks);
        } catch (error) {
            console.error('IPFS download failed:', error);
            throw new Error('文件下载失败');
        }
    }

    // 从IPFS获取JSON数据
    public async getJSON<T>(hash: string): Promise<T> {
        try {
            const stream = this.ipfs.cat(hash);
            const chunks = [];
            
            for await (const chunk of stream) {
                chunks.push(chunk);
            }
            
            const data = Buffer.concat(chunks).toString();
            return JSON.parse(data);
        } catch (error) {
            console.error('IPFS JSON download failed:', error);
            throw new Error('数据下载失败');
        }
    }

    // 检查IPFS节点连接状态
    public async checkConnection(): Promise<boolean> {
        try {
            await this.ipfs.id();
            return true;
        } catch (error) {
            console.error('IPFS connection check failed:', error);
            return false;
        }
    }
} 