import hre from "hardhat";

export async function deployContract(contractName: string) {
    const Contract = await hre.ethers.getContractFactory(contractName);
    const contract = await Contract.deploy();
    await contract.waitForDeployment();
    return contract;
} 