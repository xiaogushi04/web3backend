import { BrowserProvider, JsonRpcProvider, verifyMessage } from 'ethers';
import { DIDDocument, JWTPayload } from '../types/did';

export class DIDService {
    private static instance: DIDService;
    private provider: BrowserProvider;
    private didDocument: DIDDocument | null = null;

    private constructor() {
        if (!window.ethereum) {
            throw new Error('请安装MetaMask钱包');
        }
        this.provider = new BrowserProvider(window.ethereum);
    }

    public static getInstance(): DIDService {
        if (!DIDService.instance) {
            DIDService.instance = new DIDService();
        }
        return DIDService.instance;
    }

    // 生成DID
    public async generateDID(address: string): Promise<string> {
        const network = await this.provider.getNetwork();
        return `did:ethr:${network.chainId}:${address}`;
    }

    // 创建DID文档
    public async createDIDDocument(address: string): Promise<DIDDocument> {
        const did = await this.generateDID(address);
        const signer = await this.provider.getSigner();
        const publicKey = await signer.getAddress();

        const didDocument: DIDDocument = {
            '@context': ['https://www.w3.org/ns/did/v1'],
            id: did,
            controller: did,
            verificationMethod: [{
                id: `${did}#keys-1`,
                type: 'EcdsaSecp256k1VerificationKey2019',
                controller: did,
                publicKeyHex: publicKey
            }],
            authentication: [`${did}#keys-1`],
            assertionMethod: [`${did}#keys-1`],
            keyAgreement: [],
            service: []
        };

        this.didDocument = didDocument;
        return didDocument;
    }

    // 签名消息
    public async signMessage(message: string): Promise<string> {
        const signer = await this.provider.getSigner();
        return await signer.signMessage(message);
    }

    // 验证签名
    public async verifySignature(message: string, signature: string, address: string): Promise<boolean> {
        const recoveredAddress = verifyMessage(message, signature);
        return recoveredAddress.toLowerCase() === address.toLowerCase();
    }

    // 生成JWT
    public async generateJWT(payload: Omit<JWTPayload, 'iss' | 'iat'>): Promise<string> {
        const signer = await this.provider.getSigner();
        const address = await signer.getAddress();
        const did = await this.generateDID(address);

        const now = Math.floor(Date.now() / 1000);
        const jwtPayload: JWTPayload = {
            ...payload,
            iss: did,
            iat: now
        };

        const message = JSON.stringify(jwtPayload);
        const signature = await this.signMessage(message);

        return `${btoa(JSON.stringify(jwtPayload))}.${signature}`;
    }

    // 验证JWT
    public async verifyJWT(jwt: string): Promise<boolean> {
        try {
            const [payloadBase64, signature] = jwt.split('.');
            const payload: JWTPayload = JSON.parse(atob(payloadBase64));
            
            if (payload.exp && payload.exp < Math.floor(Date.now() / 1000)) {
                return false;
            }

            const message = JSON.stringify({
                ...payload,
                signature: undefined
            });

            return await this.verifySignature(message, signature, payload.sub);
        } catch (error) {
            console.error('JWT verification failed:', error);
            return false;
        }
    }

    // 获取当前DID文档
    public getDIDDocument(): DIDDocument | null {
        return this.didDocument;
    }
}

// 创建DID
export const createDID = (privateKey: string): string => {
  // 使用私钥生成DID
  const did = `did:example:${privateKey}`;
  return did;
};

// 验证DID
export const verifyDID = (did: string): boolean => {
  // 验证DID的有效性
  return did.startsWith('did:example:');
};

// 获取DID信息
export const getDIDInfo = (did: string): { id: string; type: string } => {
  // 解析DID信息
  const parts = did.split(':');
  return { id: parts[2], type: parts[1] };
}; 