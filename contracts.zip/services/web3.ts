import { ethers } from 'ethers';
import { Web3Provider } from '@ethersproject/providers';

// 合约地址配置
export const CONTRACT_ADDRESSES = {
  NFT: process.env.REACT_APP_NFT_CONTRACT_ADDRESS || '',
  REFERENCE: process.env.REACT_APP_REFERENCE_CONTRACT_ADDRESS || '',
};

// 网络配置
export const NETWORKS = {
  MAINNET: 1,
  RINKEBY: 4,
  LOCAL: 1337,
};

// Web3Provider实例
let provider: Web3Provider | null = null;

export const getProvider = (): Web3Provider => {
  if (!provider) {
    if (typeof window.ethereum !== 'undefined') {
      provider = new ethers.providers.Web3Provider(window.ethereum);
    } else {
      throw new Error('请安装MetaMask钱包');
    }
  }
  return provider;
};

// 获取签名者
export const getSigner = () => {
  const provider = getProvider();
  return provider.getSigner();
};

// 获取合约实例
export const getContract = (address: string, abi: any) => {
  const signer = getSigner();
  return new ethers.Contract(address, abi, signer);
};

// 监听账户变化
export const onAccountsChanged = (callback: (accounts: string[]) => void) => {
  if (window.ethereum) {
    window.ethereum.on('accountsChanged', callback);
  }
};

// 监听链ID变化
export const onChainChanged = (callback: (chainId: string) => void) => {
  if (window.ethereum) {
    window.ethereum.on('chainChanged', callback);
  }
}; 