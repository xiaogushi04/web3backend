import { HardhatEthersSigner } from "@nomicfoundation/hardhat-ethers/signers";
import hre from "hardhat";
import { expect } from "chai";
import { loadFixture } from "@nomicfoundation/hardhat-network-helpers";
import { deployContract } from "../utils/deploy";

describe('AcademicNFT', () => {
  async function deployNFTFixture() {
    const [owner, author1, author2] = await hre.ethers.getSigners() as HardhatEthersSigner[];
    const nft = await deployContract('AcademicNFT');
    return { nft, owner, author1, author2 };
  }

  describe('铸造NFT', () => {
    it('应该正确铸造NFT', async () => {
      const { nft, owner, author1 } = await loadFixture(deployNFTFixture);
      
      const title = '测试论文';
      const description = '这是一篇测试论文';
      const ipfsHash = 'QmTest123';
      const authors = [author1.address];

      const tx = await nft.mintResource(
        owner.address,
        title,
        description,
        ipfsHash,
        0, // ResourceType.Paper
        authors
      );

      const receipt = await tx.wait();
      const tokenId = await nft.totalResources();

      expect(tokenId).to.equal(1n);
      
      const metadata = await nft.getResourceMetadata(1);
      expect(metadata.title).to.equal(title);
      expect(metadata.description).to.equal(description);
      expect(metadata.ipfsHash).to.equal(ipfsHash);
      expect(metadata.authors[0]).to.equal(author1.address);
    });

    it('应该记录作者资源', async () => {
      const { nft, owner, author1 } = await loadFixture(deployNFTFixture);
      
      await nft.mintResource(
        owner.address,
        '测试论文',
        '这是一篇测试论文',
        'QmTest123',
        0,
        [author1.address]
      );

      const authorResources = await nft.getAuthorResources(author1.address);
      expect(authorResources.length).to.equal(1);
      expect(authorResources[0]).to.equal(1);
    });

    it('应该拒绝没有作者的铸造', async () => {
      const { nft, owner } = await loadFixture(deployNFTFixture);
      
      await expect(
        nft.mintResource(
          owner.address,
          '测试论文',
          '这是一篇测试论文',
          'QmTest123',
          0,
          []
        )
      ).to.be.rejectedWith('Must have at least one author');
    });
  });

  describe('更新NFT', () => {
    it('应该允许所有者更新IPFS哈希', async () => {
      const { nft, owner, author1 } = await loadFixture(deployNFTFixture);
      
      await nft.mintResource(
        owner.address,
        '测试论文',
        '这是一篇测试论文',
        'QmTest123',
        0,
        [author1.address]
      );

      const newIpfsHash = 'QmNewHash';
      await nft.updateResourceIpfsHash(1, newIpfsHash);

      const metadata = await nft.getResourceMetadata(1);
      expect(metadata.ipfsHash).to.equal(newIpfsHash);
    });

    it('应该拒绝非所有者更新IPFS哈希', async () => {
      const { nft, owner, author1, author2 } = await loadFixture(deployNFTFixture);
      
      await nft.mintResource(
        owner.address,
        '测试论文',
        '这是一篇测试论文',
        'QmTest123',
        0,
        [author1.address]
      );

      await expect(
        nft.connect(author2).updateResourceIpfsHash(1, 'QmNewHash')
      ).to.be.rejectedWith('Not owner or approved');
    });
  });

  describe('查询NFT', () => {
    it('应该正确返回tokenURI', async () => {
      const { nft, owner, author1 } = await loadFixture(deployNFTFixture);
      
      const ipfsHash = 'QmTest123';
      await nft.mintResource(
        owner.address,
        '测试论文',
        '这是一篇测试论文',
        ipfsHash,
        0,
        [author1.address]
      );

      const tokenURI = await nft.tokenURI(1);
      expect(tokenURI).to.equal(ipfsHash);
    });

    it('应该正确返回资源元数据', async () => {
      const { nft, owner, author1 } = await loadFixture(deployNFTFixture);
      
      const title = '测试论文';
      const description = '这是一篇测试论文';
      const ipfsHash = 'QmTest123';
      const authors = [author1.address];

      await nft.mintResource(
        owner.address,
        title,
        description,
        ipfsHash,
        0,
        authors
      );

      const metadata = await nft.getResourceMetadata(1);
      expect(metadata.title).to.equal(title);
      expect(metadata.description).to.equal(description);
      expect(metadata.ipfsHash).to.equal(ipfsHash);
      expect(metadata.authors).to.deep.equal(authors);
      expect(metadata.resourceType).to.equal(0); // ResourceType.Paper
    });
  });
}); 