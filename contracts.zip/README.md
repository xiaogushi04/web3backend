# 区块链模块结构说明

## 目录结构
```
blockchain/
├── contracts/           # 智能合约
│   ├── NFT.sol         # NFT合约（ERC-721/1155）
│   └── Reference.sol   # 引用记录合约
├── services/           # 区块链服务
│   ├── web3.ts        # Web3实例和配置
│   ├── auth.ts        # MetaMask认证
│   └── did.ts         # DID身份系统
├── hooks/             # React Hooks
│   ├── useWallet.ts   # 钱包连接Hook
│   └── useNFT.ts      # NFT操作Hook
├── utils/             # 工具函数
│   ├── ipfs.ts        # IPFS交互工具
│   └── events.ts      # 事件监听工具
└── types/             # TypeScript类型定义
    ├── nft.ts         # NFT相关类型
    └── did.ts         # DID相关类型
```

## 主要任务
1. NFT合约开发与部署
   - 实现ERC-721/1155标准
   - 设计资源元数据结构
   - 实现铸造和转移功能

2. 引用记录合约
   - 设计引用数据结构
   - 实现引用记录和验证
   - 设计引用激励机制

3. 身份系统
   - MetaMask集成
   - DID实现
   - JWT认证

4. IPFS集成
   - 维护NFT与IPFS数据一致性
   - 实现数据同步机制

5. 事件监听
   - 实现链上事件监听
   - 处理事件回调
   - 状态同步机制 