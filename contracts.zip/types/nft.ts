export interface NFTMetadata {
  name: string;
  description: string;
  image: string;
  attributes: {
    trait_type: string;
    value: string | number;
  }[];
  properties: {
    files: {
      uri: string;
      type: string;
    }[];
    category: string;
    creators: {
      address: string;
      share: number;
    }[];
  };
}

export interface NFTData {
  tokenId: string;
  owner: string;
  metadata: NFTMetadata;
  createdAt: number;
  updatedAt: number;
}

export interface NFTContract {
  address: string;
  name: string;
  symbol: string;
  totalSupply: number;
} 