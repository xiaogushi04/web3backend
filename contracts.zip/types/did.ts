export interface DIDDocument {
  '@context': string[];
  id: string;
  controller: string;
  verificationMethod: {
    id: string;
    type: string;
    controller: string;
    publicKeyHex?: string;
    publicKeyBase58?: string;
  }[];
  authentication: string[];
  assertionMethod: string[];
  keyAgreement: string[];
  service: {
    id: string;
    type: string;
    serviceEndpoint: string;
  }[];
}

export interface JWTPayload {
  iss: string;  // 发行者
  sub: string;  // 主题
  aud: string;  // 受众
  exp: number;  // 过期时间
  iat: number;  // 发行时间
  did: string;  // DID标识符
  nonce: string; // 随机数
}

export interface AuthState {
  isAuthenticated: boolean;
  did: string | null;
  address: string | null;
  chainId: number | null;
} 