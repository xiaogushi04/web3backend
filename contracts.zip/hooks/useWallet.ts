import { useState, useEffect, useCallback } from 'react';
import { BrowserProvider, JsonRpcProvider } from 'ethers';
import { getProvider } from '../services/web3';
import { DIDService } from '../services/did';

interface WalletState {
    address: string | null;
    chainId: number | null;
    isConnected: boolean;
    isConnecting: boolean;
    error: string | null;
}

export const useWallet = () => {
    const [state, setState] = useState<WalletState>({
        address: null,
        chainId: null,
        isConnected: false,
        isConnecting: false,
        error: null
    });

    const connect = useCallback(async () => {
        if (!window.ethereum) {
            setState(prev => ({
                ...prev,
                error: '请安装MetaMask钱包'
            }));
            return;
        }

        setState(prev => ({
            ...prev,
            isConnecting: true,
            error: null
        }));

        try {
            const provider = new BrowserProvider(window.ethereum);
            const accounts = await window.ethereum.request({
                method: 'eth_requestAccounts'
            });

            const network = await provider.getNetwork();
            const address = accounts[0];

            // 初始化DID
            const didService = DIDService.getInstance();
            await didService.createDIDDocument(address);

            setState({
                address,
                chainId: network.chainId,
                isConnected: true,
                isConnecting: false,
                error: null
            });
        } catch (error) {
            setState(prev => ({
                ...prev,
                isConnecting: false,
                error: error instanceof Error ? error.message : '连接钱包失败'
            }));
        }
    }, []);

    const disconnect = useCallback(() => {
        setState({
            address: null,
            chainId: null,
            isConnected: false,
            isConnecting: false,
            error: null
        });
    }, []);

    const switchNetwork = useCallback(async (chainId: number) => {
        if (!window.ethereum) {
            setState(prev => ({
                ...prev,
                error: '请安装MetaMask钱包'
            }));
            return;
        }

        try {
            await window.ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: [{ chainId: `0x${chainId.toString(16)}` }]
            });
        } catch (error) {
            setState(prev => ({
                ...prev,
                error: error instanceof Error ? error.message : '切换网络失败'
            }));
        }
    }, []);

    useEffect(() => {
        const handleAccountsChanged = (accounts: string[]) => {
            if (accounts.length === 0) {
                disconnect();
            } else {
                setState(prev => ({
                    ...prev,
                    address: accounts[0]
                }));
            }
        };

        const handleChainChanged = (chainId: string) => {
            setState(prev => ({
                ...prev,
                chainId: parseInt(chainId, 16)
            }));
        };

        if (window.ethereum) {
            window.ethereum.on('accountsChanged', handleAccountsChanged);
            window.ethereum.on('chainChanged', handleChainChanged);
        }

        return () => {
            if (window.ethereum) {
                window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
                window.ethereum.removeListener('chainChanged', handleChainChanged);
            }
        };
    }, [disconnect]);

    return {
        ...state,
        connect,
        disconnect,
        switchNetwork
    };
}; 