import { useState, useCallback } from 'react';
import { ethers } from 'ethers';
import { getProvider, getContract, CONTRACT_ADDRESSES } from '../services/web3';
import { IPFSService } from '../utils/ipfs';
import { NFTData, NFTMetadata } from '../types/nft';

interface NFTState {
    nfts: NFTData[];
    isLoading: boolean;
    error: string | null;
}

export const useNFT = () => {
    const [state, setState] = useState<NFTState>({
        nfts: [],
        isLoading: false,
        error: null
    });

    // 铸造NFT
    const mintNFT = useCallback(async (
        title: string,
        description: string,
        file: File,
        resourceType: number,
        authors: string[]
    ) => {
        if (!title || !description || !file || !authors.length) {
            throw new Error('所有字段都是必填的');
        }

        if (!ethers.isAddress(authors[0])) {
            throw new Error('作者地址格式不正确');
        }

        setState(prev => ({
            ...prev,
            isLoading: true,
            error: null
        }));

        try {
            // 上传文件到IPFS
            const ipfsService = IPFSService.getInstance();
            const ipfsHash = await ipfsService.uploadFile(file);
            
            if (!ipfsHash) {
                throw new Error('IPFS上传失败');
            }

            // 创建元数据
            const metadata: NFTMetadata = {
                name: title,
                description,
                image: ipfsHash,
                attributes: [
                    {
                        trait_type: 'ResourceType',
                        value: resourceType
                    }
                ],
                properties: {
                    files: [{
                        uri: ipfsHash,
                        type: file.type
                    }],
                    category: 'Academic',
                    creators: authors.map(author => ({
                        address: author,
                        share: 100 / authors.length
                    }))
                }
            };

            // 上传元数据到IPFS
            const metadataHash = await ipfsService.uploadJSON(metadata);
            
            if (!metadataHash) {
                throw new Error('元数据上传失败');
            }

            // 调用合约铸造NFT
            const contract = getContract(CONTRACT_ADDRESSES.NFT, []);
            const signer = await getProvider().getSigner();
            const userAddress = await signer.getAddress();
            
            if (!userAddress) {
                throw new Error('无法获取用户地址');
            }

            const tx = await contract.mintResource(
                userAddress,
                title,
                description,
                metadataHash,
                resourceType,
                authors
            );

            const receipt = await tx.wait();
            
            if (!receipt) {
                throw new Error('交易失败');
            }

            setState(prev => ({
                ...prev,
                isLoading: false
            }));

            return tx.hash;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : '铸造NFT失败';
            setState(prev => ({
                ...prev,
                isLoading: false,
                error: errorMessage
            }));
            throw new Error(errorMessage);
        }
    }, []);

    // 获取用户的NFT列表
    const fetchUserNFTs = useCallback(async (address: string) => {
        if (!ethers.isAddress(address)) {
            throw new Error('地址格式不正确');
        }

        setState(prev => ({
            ...prev,
            isLoading: true,
            error: null
        }));

        try {
            const contract = getContract(CONTRACT_ADDRESSES.NFT, []);
            const tokenIds = await contract.getAuthorResources(address);
            
            if (!Array.isArray(tokenIds)) {
                throw new Error('获取Token ID列表失败');
            }

            const nfts = await Promise.all(
                tokenIds.map(async (tokenId: number) => {
                    try {
                        const metadata = await contract.getResourceMetadata(tokenId);
                        const owner = await contract.ownerOf(tokenId);
                        
                        if (!metadata || !owner) {
                            throw new Error(`获取Token ${tokenId} 的元数据失败`);
                        }

                        const nftData: NFTData = {
                            tokenId: tokenId.toString(),
                            owner,
                            metadata: {
                                name: metadata.title,
                                description: metadata.description,
                                image: metadata.ipfsHash,
                                attributes: [
                                    {
                                        trait_type: 'ResourceType',
                                        value: metadata.resourceType
                                    }
                                ],
                                properties: {
                                    files: [{
                                        uri: metadata.ipfsHash,
                                        type: 'application/octet-stream'
                                    }],
                                    category: 'Academic',
                                    creators: metadata.authors.map((author: string) => ({
                                        address: author,
                                        share: 100 / metadata.authors.length
                                    }))
                                }
                            },
                            createdAt: metadata.timestamp.toNumber(),
                            updatedAt: metadata.timestamp.toNumber()
                        };
                        return nftData;
                    } catch (error) {
                        console.error(`处理Token ${tokenId}时出错:`, error);
                        return null;
                    }
                })
            );

            // 过滤掉处理失败的NFT
            const validNFTs = nfts.filter((nft): nft is NFTData => nft !== null);

            setState({
                nfts: validNFTs,
                isLoading: false,
                error: null
            });
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : '获取NFT列表失败';
            setState(prev => ({
                ...prev,
                isLoading: false,
                error: errorMessage
            }));
            throw new Error(errorMessage);
        }
    }, []);

    // 更新NFT元数据
    const updateNFTMetadata = useCallback(async (
        tokenId: string,
        newIpfsHash: string
    ) => {
        if (!tokenId || !newIpfsHash) {
            throw new Error('Token ID和IPFS哈希都是必填的');
        }

        setState(prev => ({
            ...prev,
            isLoading: true,
            error: null
        }));

        try {
            const contract = getContract(CONTRACT_ADDRESSES.NFT, []);
            const tx = await contract.updateResourceIpfsHash(tokenId, newIpfsHash);
            const receipt = await tx.wait();

            if (!receipt) {
                throw new Error('交易失败');
            }

            setState(prev => ({
                ...prev,
                isLoading: false
            }));

            return tx.hash;
        } catch (error) {
            const errorMessage = error instanceof Error ? error.message : '更新NFT元数据失败';
            setState(prev => ({
                ...prev,
                isLoading: false,
                error: errorMessage
            }));
            throw new Error(errorMessage);
        }
    }, []);

    return {
        ...state,
        mintNFT,
        fetchUserNFTs,
        updateNFTMetadata
    };
}; 